#!/bin/sh
set -eu
BASE="/volume1/web/PZ_REVIZE_NAS_SERVER"
PY="$BASE/venv/bin/python"
cd "$BASE"
API_KEY=$($PY -c 'import json; d=json.load(open("server_config.json", encoding="utf-8")); print(d.get("api_token") or d.get("api_key") or d.get("token") or "")')
if [ -z "$API_KEY" ]; then
  echo "CHYBA: API klíč nebyl nalezen v server_config.json"
  exit 1
fi

echo "=== HEALTH ==="
curl -fsS http://127.0.0.1:8767/health; echo

echo "=== WINDOWS API ==="
curl -fsS -H "X-API-Key: $API_KEY" http://127.0.0.1:8767/api/status; echo

echo "=== ANDROID API ==="
curl -fsS -H "X-API-Key: $API_KEY" http://127.0.0.1:8767/api/mobile/status; echo
