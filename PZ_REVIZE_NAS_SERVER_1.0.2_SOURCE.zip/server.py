#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import secrets
import shutil
import sqlite3
import sys
import tempfile
import threading
import zipfile
from datetime import datetime
from email.parser import BytesParser
from email.policy import default as email_policy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from pz_mobile_server import Store, now

VERSION = "1.0.2"
SNAPSHOT_FORMAT = "PZ-REVIZE-SNAPSHOT-1"
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "pz_revize_shared.db"
ATTACHMENTS_DIR = DATA_DIR / "attachments"
CONFIG_PATH = BASE_DIR / "server_config.json"
STATE_PATH = DATA_DIR / "state.json"
PORT = int(os.environ.get("PZ_REVIZE_PORT", "8767"))
HOST = os.environ.get("PZ_REVIZE_HOST", "0.0.0.0")

PATH_FIELDS = [
    ("revision_attachments", "stored_path"),
    ("revision_documents", "stored_path"),
    ("revision_photos", "stored_path"),
    ("revision_defects", "photo_path"),
    ("rt_profile", "logo_path"),
    ("rt_profile", "stamp_path"),
    ("rt_profile", "signature_path"),
]


def sha256_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_member(name):
    p = Path(name)
    return not p.is_absolute() and ".." not in p.parts


def atomic_write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(str(tmp), str(path))


def sqlite_backup(src, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        dest.unlink()
    con_src = sqlite3.connect(str(src), timeout=30)
    con_dst = sqlite3.connect(str(dest), timeout=30)
    try:
        con_src.backup(con_dst)
    finally:
        con_dst.close()
        con_src.close()


def validate_database(path):
    if not path.exists() or path.stat().st_size == 0:
        raise ValueError("Databáze PZ-REVIZE neexistuje nebo je prázdná.")
    con = sqlite3.connect(str(path), timeout=30)
    try:
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"customers", "revisions"}.issubset(tables):
            raise ValueError("Databáze nemá očekávanou strukturu PZ-REVIZE.")
        row = con.execute("PRAGMA integrity_check").fetchone()
        if not row or str(row[0]).lower() != "ok":
            raise ValueError("Kontrola integrity databáze selhala: %s" % (row[0] if row else "bez výsledku"))
    finally:
        con.close()


def read_json(path):
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


class ServerState:
    def __init__(self):
        self.db_path = DB_PATH
        self.attachments = ATTACHMENTS_DIR
        self.config_path = CONFIG_PATH
        self.state_path = STATE_PATH
        self.lock = threading.RLock()
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.attachments.mkdir(parents=True, exist_ok=True)
        (DATA_DIR / "backups").mkdir(parents=True, exist_ok=True)
        self.config = self._load_config()
        self.state_data = self._load_state()
        self.api_key = self._get_api_key()

    def _load_config(self):
        cfg = read_json(self.config_path)
        if not cfg:
            cfg = {"host": HOST, "port": PORT}
        return cfg

    def _get_api_key(self):
        env_key = os.environ.get("PZ_API_KEY", "").strip()
        if env_key:
            return env_key
        for key in ("api_key", "api_token", "token"):
            value = str(self.config.get(key, "") or "").strip()
            if value:
                return value
        value = secrets.token_urlsafe(32)
        # Nové instalace používají api_token, aby odpovídaly ostatním PZ serverům.
        self.config["api_token"] = value
        self.config.setdefault("host", HOST)
        self.config.setdefault("port", PORT)
        atomic_write_json(self.config_path, self.config)
        return value

    def _load_state(self):
        state = read_json(self.state_path)
        if not state:
            state = {"generation": 0, "created_at": now()}
            atomic_write_json(self.state_path, state)
        return state

    @property
    def generation(self):
        for key in ("generation", "server_generation", "sync_generation"):
            try:
                if key in self.state_data:
                    return int(self.state_data.get(key, 0) or 0)
            except Exception:
                pass
        return 0

    def save_state(self):
        self.state_data["generation"] = self.generation
        self.state_data["server_version"] = VERSION
        atomic_write_json(self.state_path, self.state_data)

    def bump_generation(self, client, action):
        new_gen = self.generation + 1
        self.state_data["generation"] = new_gen
        self.state_data["updated_at"] = now()
        self.state_data["last_client"] = client
        self.state_data["last_action"] = action
        self.state_data["server_version"] = VERSION
        atomic_write_json(self.state_path, self.state_data)
        return new_gen

    def db_ready(self):
        try:
            return self.db_path.exists() and self.db_path.stat().st_size > 0
        except Exception:
            return False

    def integrity(self):
        if not self.db_ready():
            return "missing"
        try:
            con = sqlite3.connect(str(self.db_path), timeout=10)
            try:
                row = con.execute("PRAGMA integrity_check").fetchone()
                return str(row[0]) if row else "unknown"
            finally:
                con.close()
        except Exception as exc:
            return "error: %s" % exc

    def status(self):
        return {
            "ok": True,
            "service": "PZ-REVIZE NAS",
            "server": "PZ-REVIZE NAS Server",
            "version": VERSION,
            "generation": self.generation,
            "database_ready": self.db_ready(),
            "db_exists": self.db_ready(),
            "db": self.db_path.name,
            "db_size": self.db_path.stat().st_size if self.db_ready() else 0,
            "integrity_check": self.integrity(),
            "time": now(),
        }

    def get_store(self):
        if not self.db_ready():
            raise FileNotFoundError("Na NAS není databáze data/pz_revize_shared.db.")
        validate_database(self.db_path)
        return Store(self.db_path, self.attachments)

    def _backup_current(self, prefix="before_import"):
        if not self.db_ready():
            return ""
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = DATA_DIR / "backups" / ("pz_revize_%s_%s.db" % (prefix, stamp))
        sqlite_backup(self.db_path, dest)
        return str(dest)

    def import_snapshot(self, bundle, expected_generation, client_name):
        with self.lock:
            if int(expected_generation) != self.generation:
                return {
                    "conflict": True,
                    "server_generation": self.generation,
                    "message": "NAS byl mezitím změněn. Data nebyla přepsána.",
                }
            stage = Path(tempfile.mkdtemp(prefix="pz_revize_nas_push_"))
            try:
                zip_path = stage / "incoming.zip"
                zip_path.write_bytes(bundle)
                extract = stage / "extract"
                extract.mkdir()
                with zipfile.ZipFile(str(zip_path), "r") as z:
                    for info in z.infolist():
                        if not safe_member(info.filename):
                            raise ValueError("Synchronizační balík obsahuje neplatnou cestu.")
                    z.extractall(str(extract))
                db_in = extract / "pz_revize.db"
                manifest_path = extract / "manifest.json"
                if not db_in.exists() or not manifest_path.exists():
                    raise ValueError("Synchronizační balík je neúplný.")
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                if manifest.get("format") != SNAPSHOT_FORMAT:
                    raise ValueError("Nepodporovaný formát synchronizačního balíku.")
                validate_database(db_in)
                expected_sha = str(manifest.get("db_sha256", "") or "")
                if expected_sha and expected_sha != sha256_file(db_in):
                    raise ValueError("Kontrolní součet databáze v balíku nesouhlasí.")

                backup = self._backup_current("before_pc_push")
                for side in (Path(str(self.db_path) + "-wal"), Path(str(self.db_path) + "-shm")):
                    try:
                        side.unlink()
                    except FileNotFoundError:
                        pass
                new_db = self.db_path.with_suffix(self.db_path.suffix + ".new")
                shutil.copy2(str(db_in), str(new_db))
                os.replace(str(new_db), str(self.db_path))
                for side in (Path(str(self.db_path) + "-wal"), Path(str(self.db_path) + "-shm")):
                    try:
                        side.unlink()
                    except FileNotFoundError:
                        pass

                src_att = extract / "attachments"
                new_att = self.attachments.with_name(self.attachments.name + ".new")
                old_att = self.attachments.with_name(self.attachments.name + ".old")
                shutil.rmtree(str(new_att), ignore_errors=True)
                shutil.rmtree(str(old_att), ignore_errors=True)
                new_att.mkdir(parents=True, exist_ok=True)
                if src_att.exists():
                    shutil.copytree(str(src_att), str(new_att), dirs_exist_ok=True)
                if self.attachments.exists():
                    os.replace(str(self.attachments), str(old_att))
                os.replace(str(new_att), str(self.attachments))
                shutil.rmtree(str(old_att), ignore_errors=True)
                gen = self.bump_generation(client_name or "PZ-REVIZE PC", "desktop_push")
                return {"ok": True, "generation": gen, "backup": backup, "received_at": now()}
            finally:
                shutil.rmtree(str(stage), ignore_errors=True)

    def _normalize_paths_for_bundle(self, db_copy, bundle_att):
        bundle_att.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(str(db_copy))
        con.row_factory = sqlite3.Row
        try:
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for table, col in PATH_FIELDS:
                if table not in tables:
                    continue
                cols = {r[1] for r in con.execute("PRAGMA table_info(%s)" % table)}
                if col not in cols:
                    continue
                rows = con.execute(
                    "SELECT rowid AS rid,%s AS p FROM %s WHERE %s IS NOT NULL AND TRIM(%s)<>''" % (col, table, col, col)
                ).fetchall()
                for row in rows:
                    raw = str(row["p"] or "").strip()
                    if not raw:
                        continue
                    rel = raw.replace("\\", "/")
                    src = None
                    if rel.startswith("attachments/"):
                        src = self.attachments / Path(rel).name
                    else:
                        candidate = Path(raw)
                        if candidate.exists() and candidate.is_file():
                            src = candidate
                    if src and src.exists():
                        name = src.name
                        dest = bundle_att / name
                        if not dest.exists():
                            shutil.copy2(str(src), str(dest))
                        con.execute("UPDATE %s SET %s=? WHERE rowid=?" % (table, col), ("attachments/" + name, row["rid"]))
            try:
                con.execute("DELETE FROM settings WHERE key LIKE 'nas_%'")
            except sqlite3.OperationalError:
                pass
            con.commit()
        finally:
            con.close()
        if self.attachments.exists():
            for p in self.attachments.rglob("*"):
                if p.is_file():
                    dest = bundle_att / p.name
                    if not dest.exists():
                        shutil.copy2(str(p), str(dest))

    def build_snapshot(self):
        with self.lock:
            if not self.db_ready():
                raise FileNotFoundError("Na NAS není databáze k synchronizaci.")
            validate_database(self.db_path)
            stage = Path(tempfile.mkdtemp(prefix="pz_revize_nas_pull_"))
            try:
                db_copy = stage / "pz_revize.db"
                sqlite_backup(self.db_path, db_copy)
                bundle_att = stage / "attachments"
                self._normalize_paths_for_bundle(db_copy, bundle_att)
                manifest = {
                    "format": SNAPSHOT_FORMAT,
                    "client_version": "PZ-REVIZE NAS Server " + VERSION,
                    "created_at": now(),
                    "db_sha256": sha256_file(db_copy),
                    "generation": self.generation,
                    "source_generation": self.generation,
                    "file_count": sum(1 for p in bundle_att.rglob("*") if p.is_file()),
                }
                out = stage / "snapshot.zip"
                with zipfile.ZipFile(str(out), "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
                    z.write(str(db_copy), "pz_revize.db")
                    for p in bundle_att.rglob("*"):
                        if p.is_file():
                            z.write(str(p), "attachments/" + p.name)
                    z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
                return out.read_bytes()
            finally:
                shutil.rmtree(str(stage), ignore_errors=True)

    def mobile_bootstrap(self):
        with self.lock:
            out = self.get_store().bootstrap()
            out["generation"] = self.generation
            out["server"] = "PZ-REVIZE NAS Server"
            out["version"] = VERSION
            return out

    def mobile_push(self, payload):
        with self.lock:
            # Konzistentní záloha před první změnou z mobilu v daném požadavku.
            changed_request = any(payload.get(k) for k in ("customers", "revisions", "measurements", "checklist", "defects", "photos", "deletions"))
            backup = self._backup_current("before_mobile_push") if changed_request else ""
            result = self.get_store().push(payload)
            changed = len(result.get("accepted") or []) + len(result.get("deleted") or [])
            if changed:
                result["generation"] = self.bump_generation("PZ-REVIZE Mobile", "mobile_push")
            else:
                result["generation"] = self.generation
            result["server"] = "PZ-REVIZE NAS Server"
            if backup:
                result["backup"] = backup
            return result


def parse_multipart(content_type, body):
    raw = ("Content-Type: " + content_type + "\r\nMIME-Version: 1.0\r\n\r\n").encode("utf-8") + body
    msg = BytesParser(policy=email_policy).parsebytes(raw)
    fields = {}
    files = {}
    if not msg.is_multipart():
        raise ValueError("Požadavek není multipart/form-data.")
    for part in msg.iter_parts():
        name = part.get_param("name", header="content-disposition")
        if not name:
            continue
        data = part.get_payload(decode=True) or b""
        filename = part.get_filename()
        if filename is not None:
            files[name] = data
        else:
            fields[name] = data.decode(part.get_content_charset() or "utf-8", "replace")
    return fields, files


class Api(BaseHTTPRequestHandler):
    server_version = "PZRevizeNAS/" + VERSION

    @property
    def state(self):
        return self.server.state

    def _json(self, code, obj):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _auth(self):
        if self.headers.get("X-API-Key", "") != self.state.api_key:
            self._json(401, {"error": "Neplatný API klíč.", "detail": "Neplatný API klíč."})
            return False
        return True

    def do_GET(self):
        p = urlparse(self.path).path
        if p in ("/health", "/api/health"):
            self._json(200, {
                "ok": True,
                "server": "PZ-REVIZE NAS Server",
                "version": VERSION,
                "database_ready": self.state.db_ready(),
                "db": self.state.db_path.name,
            })
            return
        if not self._auth():
            return
        try:
            if p in ("/", "/api/status"):
                self._json(200, self.state.status())
            elif p in ("/api/mobile", "/api/mobile/", "/api/mobile/status"):
                self._json(200, self.state.status())
            elif p == "/api/mobile/bootstrap":
                self._json(200, self.state.mobile_bootstrap())
            elif p == "/api/sync/pull":
                data = self.state.build_snapshot()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("X-PZ-Generation", str(self.state.generation))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)
            else:
                self._json(404, {"error": "Neznámá cesta.", "detail": "Neznámá cesta."})
        except FileNotFoundError as exc:
            self._json(404, {"error": str(exc), "detail": str(exc)})
        except Exception as exc:
            self._json(500, {"error": str(exc), "detail": str(exc)})

    def do_POST(self):
        if not self._auth():
            return
        p = urlparse(self.path).path
        try:
            n = int(self.headers.get("Content-Length", "0") or 0)
            if n > 600 * 1024 * 1024:
                raise ValueError("Požadavek je příliš velký (max. 600 MB).")
            body = self.rfile.read(n) if n else b""
            if p == "/api/mobile/push":
                data = json.loads(body.decode("utf-8")) if body else {}
                self._json(200, self.state.mobile_push(data))
                return
            if p == "/api/sync/push":
                fields, files = parse_multipart(self.headers.get("Content-Type", ""), body)
                expected = int(fields.get("expected_generation", "0") or 0)
                client = fields.get("client_name", "PZ-REVIZE PC")
                bundle = files.get("bundle")
                if not bundle:
                    raise ValueError("Chybí synchronizační balík.")
                result = self.state.import_snapshot(bundle, expected, client)
                if result.get("conflict"):
                    self._json(409, {"detail": {"server_generation": result["server_generation"], "message": result["message"]}})
                else:
                    self._json(200, result)
                return
            self._json(404, {"error": "Neznámá cesta.", "detail": "Neznámá cesta."})
        except FileNotFoundError as exc:
            self._json(404, {"error": str(exc), "detail": str(exc)})
        except Exception as exc:
            self._json(500, {"error": str(exc), "detail": str(exc)})

    def log_message(self, fmt, *args):
        sys.stdout.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))
        sys.stdout.flush()


def main():
    state = ServerState()
    try:
        validate_database(state.db_path)
        db_status = "OK"
    except Exception as exc:
        db_status = "CHYBA: %s" % exc

    srv = ThreadingHTTPServer((HOST, PORT), Api)
    srv.state = state
    print("PZ-REVIZE NAS Server", VERSION)
    print("Base:", BASE_DIR)
    print("DB:", state.db_path)
    print("Attachments:", state.attachments)
    print("Port:", PORT)
    print("Database:", db_status)
    print("Generation:", state.generation)
    print("Windows API: /api/status, /api/sync/push, /api/sync/pull")
    print("Android API: /api/mobile/status, /api/mobile/bootstrap, /api/mobile/push")
    print("Health: /health nebo /api/health")
    print("Ukončení: Ctrl+C")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
