#!/bin/sh
set -eu
TARGET="/volume1/web/PZ_REVIZE_NAS_SERVER"
SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP="$TARGET/data/update_backups/v1.0.2_$STAMP"

if [ ! -d "$TARGET" ]; then
  echo "CHYBA: Cílová složka neexistuje: $TARGET"
  exit 1
fi

printf '%s\n' "Aktualizace PZ-REVIZE NAS na 1.0.2" \
  "Cíl: $TARGET" \
  "ZACHOVÁ se: data/, venv/, server_config.json" \
  "Před změnou se zazálohují stávající serverové soubory." \
  "Pokračovat? Napište ANO:"
read ANSWER
[ "$ANSWER" = "ANO" ] || { echo "Zrušeno."; exit 1; }

mkdir -p "$BACKUP"
for F in server.py pz_mobile_server.py spustit_server.sh zastavit_server.sh restart_server.sh; do
  if [ -f "$TARGET/$F" ]; then cp -p "$TARGET/$F" "$BACKUP/$F"; fi
done

# Záloha produkční DB přes sqlite backup, pokud je dostupný Python.
if [ -x "$TARGET/venv/bin/python" ] && [ -f "$TARGET/data/pz_revize_shared.db" ]; then
  "$TARGET/venv/bin/python" - "$TARGET/data/pz_revize_shared.db" "$BACKUP/pz_revize_shared.db" <<'PY'
import sqlite3,sys
s=sqlite3.connect(sys.argv[1]); d=sqlite3.connect(sys.argv[2]); s.backup(d); d.close(); s.close()
PY
fi

/bin/sh "$TARGET/zastavit_server.sh" 2>/dev/null || true

for F in server.py pz_mobile_server.py spustit_server.sh zastavit_server.sh restart_server.sh; do
  cp -p "$SRC/$F" "$TARGET/$F"
done
chmod +x "$TARGET/spustit_server.sh" "$TARGET/zastavit_server.sh" "$TARGET/restart_server.sh"

"$TARGET/venv/bin/python" -m py_compile "$TARGET/server.py" "$TARGET/pz_mobile_server.py"

if /bin/sh "$TARGET/spustit_server.sh"; then
  sleep 2
  if curl -fsS "http://127.0.0.1:8767/health" >/tmp/pz_revize_health.$$ 2>/dev/null; then
    cat /tmp/pz_revize_health.$$
    rm -f /tmp/pz_revize_health.$$
    echo
    echo "Aktualizace dokončena."
    echo "Zkontrolujte database_ready=true."
    exit 0
  fi
fi

echo "CHYBA: Nový server neprošel kontrolou. Probíhá návrat serverových souborů."
/bin/sh "$TARGET/zastavit_server.sh" 2>/dev/null || true
for F in server.py pz_mobile_server.py spustit_server.sh zastavit_server.sh restart_server.sh; do
  if [ -f "$BACKUP/$F" ]; then cp -p "$BACKUP/$F" "$TARGET/$F"; fi
done
if [ -f "$BACKUP/pz_revize_shared.db" ]; then cp -p "$BACKUP/pz_revize_shared.db" "$TARGET/data/pz_revize_shared.db"; fi
chmod +x "$TARGET"/*.sh 2>/dev/null || true
/bin/sh "$TARGET/spustit_server.sh" 2>/dev/null || true
exit 1
