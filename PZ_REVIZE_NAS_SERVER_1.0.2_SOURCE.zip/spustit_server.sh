#!/bin/sh
set -u
BASE="/volume1/web/PZ_REVIZE_NAS_SERVER"
PY="$BASE/venv/bin/python"
PIDFILE="$BASE/server.pid"
LOG="$BASE/server.log"

cd "$BASE" || exit 1

if [ ! -x "$PY" ]; then
  echo "CHYBA: Nenalezen Python: $PY"
  exit 1
fi

if [ -f "$PIDFILE" ]; then
  PID=$(cat "$PIDFILE" 2>/dev/null || true)
  if [ -n "${PID:-}" ] && kill -0 "$PID" 2>/dev/null; then
    echo "PZ-REVIZE NAS server už běží (PID $PID)."
    exit 0
  fi
  rm -f "$PIDFILE"
fi

# Odstraní jen ručně spuštěnou starou/testovací variantu ze stejné produkční složky.
for PROC in /proc/[0-9]*; do
  [ -d "$PROC" ] || continue
  PID=${PROC#/proc/}
  CWD=$(readlink "$PROC/cwd" 2>/dev/null || true)
  [ "$CWD" = "$BASE" ] || continue
  CMD=$(tr '\000' ' ' < "$PROC/cmdline" 2>/dev/null || true)
  case "$CMD" in
    *"pz_nas_server.py"*) kill "$PID" 2>/dev/null || true ;;
  esac
done
sleep 1

nohup "$PY" "$BASE/server.py" >> "$LOG" 2>&1 &
PID=$!
echo "$PID" > "$PIDFILE"
sleep 2

if kill -0 "$PID" 2>/dev/null; then
  echo "PZ-REVIZE NAS server spuštěn (PID $PID, port 8767)."
  exit 0
fi

echo "CHYBA: Server se nespustil. Poslední řádky logu:"
tail -n 40 "$LOG" 2>/dev/null || true
rm -f "$PIDFILE"
exit 1
