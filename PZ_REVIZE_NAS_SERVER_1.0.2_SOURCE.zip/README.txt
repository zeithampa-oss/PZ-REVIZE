PZ-REVIZE NAS SERVER 1.0.2 – WINDOWS + ANDROID
================================================

Tato verze je určena přímo pro stávající instalaci:
  /volume1/web/PZ_REVIZE_NAS_SERVER

Používá STÁVAJÍCÍ produkční data:
  data/pz_revize_shared.db
  data/attachments/
  data/state.json
  server_config.json

DŮLEŽITÉ
---------
- NEMAŽTE data/, venv/ ani server_config.json.
- Balík záměrně neobsahuje data/ ani produkční server_config.json.
- Stejný server obsluhuje Windows i Android na portu 8767.
- API klíč zůstává stávající z server_config.json (api_token/api_key).

DOPORUČENÉ NASAZENÍ PŘES SSH
-----------------------------
1. Rozbalte ZIP mimo produkční adresář.
2. V rozbalené složce:

   chmod +x AKTUALIZOVAT_SERVER_1_0_2.sh
   ./AKTUALIZOVAT_SERVER_1_0_2.sh

3. Na výzvu napište přesně:

   ANO

Aktualizátor zachová produkční data a při chybě se pokusí obnovit předchozí server.

RUČNÍ PŘEHRÁNÍ SOUBORŮ
-----------------------
Pokud chcete soubory přehrát ručně přes File Station, nahraďte pouze:
  server.py
  pz_mobile_server.py
  spustit_server.sh
  zastavit_server.sh
  restart_server.sh

Potom přes SSH:

  cd /volume1/web/PZ_REVIZE_NAS_SERVER
  chmod +x spustit_server.sh zastavit_server.sh restart_server.sh
  ./restart_server.sh

OVĚŘENÍ
-------
Bez API klíče:

  curl -s http://127.0.0.1:8767/health

Správně má obsahovat:
  "ok": true
  "version": "1.0.2"
  "database_ready": true
  "db": "pz_revize_shared.db"

Načtení stávajícího API klíče do proměnné (podporuje api_token i api_key):

  cd /volume1/web/PZ_REVIZE_NAS_SERVER
  API_KEY=$(./venv/bin/python -c 'import json; d=json.load(open("server_config.json")); print(d.get("api_token") or d.get("api_key") or d.get("token") or "")')

Windows API:
  curl -s -H "X-API-Key: $API_KEY" http://127.0.0.1:8767/api/status

Android API:
  curl -s -H "X-API-Key: $API_KEY" http://127.0.0.1:8767/api/mobile/status

Oba endpointy musí vrátit ok=true a database_ready=true.

ANDROID
-------
V PZ-REVIZE Mobile 0.4.1 nastavte:
  LAN: http://192.168.100.198:8767
  VPN: http://100.108.171.83:8767
  API klíč: stejný jako v server_config.json

Server podporuje:
  /api/mobile/status
  /api/mobile/bootstrap
  /api/mobile/push

WINDOWS
-------
Zůstávají zachované endpointy:
  /api/status
  /api/sync/pull
  /api/sync/push

POZNÁMKA K BEZPEČNOSTI
-----------------------
Port 8767 používejte pouze v LAN/VPN. Neotevírejte jej přímo do internetu.
