#!/usr/bin/env python3
from __future__ import annotations

import argparse, base64, hashlib, json, os, secrets, sqlite3, sys
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

VERSION = "1.0.2"
CONFIG_NAME = "pz_mobile_server.json"


def now():
    return datetime.now().isoformat(timespec="seconds")

def sha(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def txt(v):
    return "" if v is None else str(v)

def as_int(v):
    try: return int(v or 0)
    except Exception: return 0

class Store:
    def __init__(self, db_path: Path, attachments: Path):
        self.db_path = db_path
        self.attachments = attachments
        self.attachments.mkdir(parents=True, exist_ok=True)
        if not db_path.exists():
            raise FileNotFoundError(f"Databáze nebyla nalezena: {db_path}")
        self._ensure_aux()

    def con(self):
        c = sqlite3.connect(self.db_path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA busy_timeout=30000")
        return c

    def cols(self, c, table):
        return {r[1] for r in c.execute(f"PRAGMA table_info({table})")}

    def _ensure_aux(self):
        with self.con() as c:
            c.execute("CREATE TABLE IF NOT EXISTS mobile_sync_log(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, client TEXT, action TEXT, detail TEXT)")

    def log(self, action, detail="", client="android"):
        with self.con() as c:
            c.execute("INSERT INTO mobile_sync_log(client,action,detail) VALUES(?,?,?)", (client, action, detail[:2000]))

    def customer_dict(self, r):
        d={"server_id":r["id"],"name":txt(r["name"]),"ico":txt(r["ico"]),"address":txt(r["address"]),"contact":txt(r["contact"]),"note":txt(r["note"]),"updated_at":txt(r["created_at"])}
        d["server_hash"]=sha({k:d[k] for k in ("name","ico","address","contact","note")});return d

    def revision_rows(self,c):
        cols=self.cols(c,"revisions")
        name_expr="COALESCE(NULLIF(r.object_name_text,''),o.name,'')" if "object_name_text" in cols else "COALESCE(o.name,'')"
        addr_expr="COALESCE(NULLIF(r.object_address_text,''),o.address,'')" if "object_address_text" in cols else "COALESCE(o.address,'')"
        return c.execute(f"SELECT r.*, {name_expr} AS _obj_name, {addr_expr} AS _obj_addr FROM revisions r LEFT JOIN objects o ON o.id=r.object_id ORDER BY r.id").fetchall()

    def revision_dict(self,r):
        keys=r.keys()
        if "note" in keys:
            note=txt(r["note"])
        else:
            try: note=txt(json.loads(txt(r["special_json"]) or "{}").get("_mobile_note","")) if "special_json" in keys else ""
            except Exception: note=""
        d={"server_id":r["id"],"customer_server_id":as_int(r["customer_id"]),"revision_no":txt(r["revision_no"]),"revision_type":txt(r["revision_type"]),"object_name":txt(r["_obj_name"]),"object_address":txt(r["_obj_addr"]),"status":txt(r["status"]),"note":note,"updated_at":txt(r["updated_at"] if "updated_at" in keys else r["created_at"])}
        d["server_hash"]=sha({k:d[k] for k in ("customer_server_id","revision_no","revision_type","object_name","object_address","status","note")});return d

    def measurement_dict(self,kind,r,revision_id):
        if kind=="CIRCUIT":
            d={"server_id":r["id"],"revision_server_id":revision_id,"remote_kind":kind,"element":txt(r["designation"]),"measure_type":txt(r["row_type"] or "CIRCUIT"),"v1":txt(r["measured_voltage"]),"v2":txt(r["riso"]),"v3":txt(r["zs"]),"v4":txt(r["ik"]),"unit1":"V","unit2":"MΩ","unit3":"Ω","unit4":"A","note":txt(r["note"]),"done":1 if txt(r["result"]).strip() else 0,"sort_order":as_int(r["sort_order"]),"updated_at":""}
        elif kind=="MACHINE":
            v1=txt(r["measured_voltage"]) or txt(r["value"])
            u1="V" if txt(r["measured_voltage"]) else txt(r["unit"])
            d={"server_id":r["id"],"revision_server_id":revision_id,"remote_kind":kind,"element":txt(r["designation"]),"measure_type":txt(r["measurement_type"] or r["row_type"] or "MEASUREMENT"),"v1":v1,"v2":txt(r["riso"]),"v3":txt(r["zs"]),"v4":txt(r["ik"]),"unit1":u1,"unit2":"MΩ","unit3":"Ω","unit4":"A","note":txt(r["note"]),"done":1 if txt(r["result"]).strip() else 0,"sort_order":as_int(r["sort_order"]),"updated_at":""}
        else:
            d={"server_id":r["id"],"revision_server_id":revision_id,"remote_kind":kind,"element":txt(r["designation"]),"measure_type":txt(r["item_type"]),"v1":txt(r["continuity"]),"v2":txt(r["earth_resistance"]),"v3":"","v4":"","unit1":"Ω","unit2":"Ω","unit3":"","unit4":"","note":txt(r["note"]),"done":1 if txt(r["result"]).strip() else 0,"sort_order":0,"updated_at":""}
        d["server_hash"]=sha({k:d[k] for k in ("element","measure_type","v1","v2","v3","v4","note","done")});return d

    def checklist_dict(self,r):
        result=txt(r["result"]);done=0 if result in ("","NEPROVEDENO","Nehodnoceno") else 1
        d={"server_id":r["id"],"revision_server_id":r["revision_id"],"label":txt(r["label_snapshot"]),"result":result,"note":txt(r["note"]),"done":done,"sort_order":as_int(r["sort_order"]),"updated_at":""}
        d["server_hash"]=sha({k:d[k] for k in ("label","result","note","done")});return d

    def defect_dict(self,r):
        sev=txt(r["severity"] or r["defect_class"])
        d={"server_id":r["id"],"revision_server_id":r["revision_id"],"text":txt(r["defect_text"]),"severity":sev,"status":txt(r["status"]),"note":txt(r["note"]),"updated_at":""}
        d["server_hash"]=sha({k:d[k] for k in ("text","severity","status","note")});return d

    def bootstrap(self):
        out={"server":"PZ-REVIZE Mobile Bridge","version":VERSION,"generated_at":now(),"customers":[],"revisions":[],"measurements":[],"checklist":[],"defects":[]}
        with self.con() as c:
            out["customers"]=[self.customer_dict(r) for r in c.execute("SELECT id,name,ico,address,contact,note,created_at FROM customers ORDER BY id")]
            out["revisions"]=[self.revision_dict(r) for r in self.revision_rows(c)]
            for r in c.execute("SELECT * FROM circuits ORDER BY revision_id,COALESCE(sort_order,id),id"):
                out["measurements"].append(self.measurement_dict("CIRCUIT",r,r["revision_id"]))
            if "machine_measurements" in {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}:
                for r in c.execute("SELECT * FROM machine_measurements ORDER BY revision_id,COALESCE(sort_order,id),id"):
                    out["measurements"].append(self.measurement_dict("MACHINE",r,r["revision_id"]))
            for r in c.execute("SELECT * FROM lps_measurements ORDER BY revision_id,id"):
                out["measurements"].append(self.measurement_dict("LPS",r,r["revision_id"]))
            out["checklist"]=[self.checklist_dict(r) for r in c.execute("SELECT * FROM revision_inspection_items ORDER BY revision_id,sort_order,id")]
            out["defects"]=[self.defect_dict(r) for r in c.execute("SELECT * FROM revision_defects ORDER BY revision_id,id")]
        return out

    def current_customer_hash(self,c,sid):
        r=c.execute("SELECT id,name,ico,address,contact,note,created_at FROM customers WHERE id=?",(sid,)).fetchone();return None if not r else self.customer_dict(r)["server_hash"]
    def current_revision_hash(self,c,sid):
        rows=[r for r in self.revision_rows(c) if r["id"]==sid];return None if not rows else self.revision_dict(rows[0])["server_hash"]
    def current_measurement_hash(self,c,kind,sid):
        table={"CIRCUIT":"circuits","MACHINE":"machine_measurements","LPS":"lps_measurements"}.get(kind); 
        if not table:return None
        r=c.execute(f"SELECT * FROM {table} WHERE id=?",(sid,)).fetchone();return None if not r else self.measurement_dict(kind,r,r["revision_id"])["server_hash"]
    def current_check_hash(self,c,sid):
        r=c.execute("SELECT * FROM revision_inspection_items WHERE id=?",(sid,)).fetchone();return None if not r else self.checklist_dict(r)["server_hash"]
    def current_defect_hash(self,c,sid):
        r=c.execute("SELECT * FROM revision_defects WHERE id=?",(sid,)).fetchone();return None if not r else self.defect_dict(r)["server_hash"]

    def conflict(self,expected,current):
        return bool(expected and current and expected!=current)

    def push(self,payload):
        accepted=[];conflicts=[];deleted=[];id_by_uuid={}
        with self.con() as c:
            c.execute("BEGIN IMMEDIATE")
            # Customers
            for o in payload.get("customers") or []:
                uuid=txt(o.get("uuid"));sid=as_int(o.get("server_id"));cur=self.current_customer_hash(c,sid) if sid else None
                if sid and self.conflict(txt(o.get("server_hash")),cur): conflicts.append({"entity":"customer","uuid":uuid,"server_id":sid,"reason":"Zákazník byl mezitím změněn na serveru."});continue
                vals=(txt(o.get("name")),txt(o.get("ico")),txt(o.get("address")),txt(o.get("contact")),txt(o.get("note")))
                if sid:c.execute("UPDATE customers SET name=?,ico=?,address=?,contact=?,note=? WHERE id=?",vals+(sid,))
                else:sid=c.execute("INSERT INTO customers(name,ico,address,contact,note) VALUES(?,?,?,?,?)",vals).lastrowid
                id_by_uuid[uuid]=sid;h=self.current_customer_hash(c,sid);accepted.append({"entity":"customer","uuid":uuid,"server_id":sid,"server_hash":h})
            # Revisions
            rcols=self.cols(c,"revisions")
            for o in payload.get("revisions") or []:
                uuid=txt(o.get("uuid"));sid=as_int(o.get("server_id"));cid=as_int(o.get("customer_server_id")) or id_by_uuid.get(txt(o.get("customer_uuid")),0)
                if not cid: conflicts.append({"entity":"revision","uuid":uuid,"server_id":sid,"reason":"Chybí synchronizovaný zákazník."});continue
                cur=self.current_revision_hash(c,sid) if sid else None
                if sid and self.conflict(txt(o.get("server_hash")),cur):conflicts.append({"entity":"revision","uuid":uuid,"server_id":sid,"reason":"Revize byla mezitím změněna na serveru."});continue
                revno=txt(o.get("revision_no")).strip() or None
                try:
                    if sid:
                        sets=["customer_id=?","revision_no=?","revision_type=?","status=?","updated_at=CURRENT_TIMESTAMP"]
                        vals=[cid,revno,txt(o.get("revision_type")) or "ELEKTRO",txt(o.get("status")) or "Rozpracovaná"]
                        if "note" in rcols:
                            sets.append("note=?"); vals.append(txt(o.get("note")))
                        elif "special_json" in rcols:
                            oldj=c.execute("SELECT special_json FROM revisions WHERE id=?",(sid,)).fetchone();
                            try: sj=json.loads(txt(oldj[0]) or "{}") if oldj else {}
                            except Exception: sj={}
                            sj["_mobile_note"]=txt(o.get("note")); sets.append("special_json=?"); vals.append(json.dumps(sj,ensure_ascii=False))
                        if "object_name_text" in rcols:sets.append("object_name_text=?");vals.append(txt(o.get("object_name")))
                        if "object_address_text" in rcols:sets.append("object_address_text=?");vals.append(txt(o.get("object_address")))
                        vals.append(sid);c.execute("UPDATE revisions SET "+",".join(sets)+" WHERE id=?",vals)
                    else:
                        cols=["customer_id","revision_no","revision_type","status","created_at","updated_at"];vals=[cid,revno,txt(o.get("revision_type")) or "ELEKTRO",txt(o.get("status")) or "Rozpracovaná",now(),now()]
                        if "note" in rcols:
                            cols.append("note"); vals.append(txt(o.get("note")))
                        elif "special_json" in rcols:
                            cols.append("special_json"); vals.append(json.dumps({"_mobile_note":txt(o.get("note"))},ensure_ascii=False))
                        if "object_name_text" in rcols:cols.append("object_name_text");vals.append(txt(o.get("object_name")))
                        if "object_address_text" in rcols:cols.append("object_address_text");vals.append(txt(o.get("object_address")))
                        if "source_revision_id" in rcols and as_int(o.get("source_server_id")):cols.append("source_revision_id");vals.append(as_int(o.get("source_server_id")))
                        if "copy_mode" in rcols and as_int(o.get("source_server_id")):cols.append("copy_mode");vals.append("periodic")
                        sid=c.execute(f"INSERT INTO revisions({','.join(cols)}) VALUES({','.join('?' for _ in cols)})",vals).lastrowid
                except sqlite3.IntegrityError as e:
                    conflicts.append({"entity":"revision","uuid":uuid,"server_id":sid,"reason":"Číslo revize už existuje nebo je záznam v konfliktu: "+str(e)});continue
                id_by_uuid[uuid]=sid;h=self.current_revision_hash(c,sid);accepted.append({"entity":"revision","uuid":uuid,"server_id":sid,"server_hash":h})
            # Measurements
            for o in payload.get("measurements") or []:
                uuid=txt(o.get("uuid"));sid=as_int(o.get("server_id"));rid=as_int(o.get("revision_server_id")) or id_by_uuid.get(txt(o.get("revision_uuid")),0);kind=txt(o.get("remote_kind"))
                if not kind: kind={"ELEKTRO":"CIRCUIT","STROJ":"MACHINE","LPS":"LPS"}.get(txt(o.get("revision_type")),"MACHINE")
                if not rid:conflicts.append({"entity":"measurement","uuid":uuid,"server_id":sid,"reason":"Chybí synchronizovaná revize."});continue
                cur=self.current_measurement_hash(c,kind,sid) if sid else None
                if sid and self.conflict(txt(o.get("server_hash")),cur):conflicts.append({"entity":"measurement","uuid":uuid,"server_id":sid,"reason":"Měření bylo mezitím změněno na serveru."});continue
                done=as_int(o.get("done"));result="Provedeno" if done else ""
                if kind=="CIRCUIT":
                    if sid:c.execute("UPDATE circuits SET measured_voltage=?,riso=?,zs=?,ik=?,note=?,result=? WHERE id=?",(txt(o.get("v1")),txt(o.get("v2")),txt(o.get("v3")),txt(o.get("v4")),txt(o.get("note")),result,sid))
                    else:sid=c.execute("INSERT INTO circuits(revision_id,designation,row_type,measured_voltage,riso,zs,ik,note,result,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?)",(rid,txt(o.get("element")),"CIRCUIT",txt(o.get("v1")),txt(o.get("v2")),txt(o.get("v3")),txt(o.get("v4")),txt(o.get("note")),result,as_int(o.get("sort_order")))).lastrowid
                elif kind=="LPS":
                    if sid:c.execute("UPDATE lps_measurements SET continuity=?,earth_resistance=?,note=?,result=? WHERE id=?",(txt(o.get("v1")),txt(o.get("v2")),txt(o.get("note")),result,sid))
                    else:sid=c.execute("INSERT INTO lps_measurements(revision_id,designation,item_type,continuity,earth_resistance,result,note) VALUES(?,?,?,?,?,?,?)",(rid,txt(o.get("element")),txt(o.get("measure_type")),txt(o.get("v1")),txt(o.get("v2")),result,txt(o.get("note")))).lastrowid
                else:
                    if sid:c.execute("UPDATE machine_measurements SET measured_voltage=?,value=?,riso=?,zs=?,ik=?,note=?,result=? WHERE id=?",(txt(o.get("v1")),txt(o.get("v1")),txt(o.get("v2")),txt(o.get("v3")),txt(o.get("v4")),txt(o.get("note")),result,sid))
                    else:sid=c.execute("INSERT INTO machine_measurements(revision_id,designation,measurement_type,value,unit,measured_voltage,riso,zs,ik,note,result,row_type,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(rid,txt(o.get("element")),txt(o.get("measure_type")),txt(o.get("v1")),txt(o.get("unit1")),txt(o.get("v1")),txt(o.get("v2")),txt(o.get("v3")),txt(o.get("v4")),txt(o.get("note")),result,"MEASUREMENT",as_int(o.get("sort_order")))).lastrowid
                h=self.current_measurement_hash(c,kind,sid);accepted.append({"entity":"measurement","uuid":uuid,"server_id":sid,"server_hash":h})
            # Checklist
            for o in payload.get("checklist") or []:
                uuid=txt(o.get("uuid"));sid=as_int(o.get("server_id"));rid=as_int(o.get("revision_server_id")) or id_by_uuid.get(txt(o.get("revision_uuid")),0)
                if not rid:conflicts.append({"entity":"checklist","uuid":uuid,"server_id":sid,"reason":"Chybí synchronizovaná revize."});continue
                cur=self.current_check_hash(c,sid) if sid else None
                if sid and self.conflict(txt(o.get("server_hash")),cur):conflicts.append({"entity":"checklist","uuid":uuid,"server_id":sid,"reason":"Kontrolní bod byl mezitím změněn na serveru."});continue
                result=txt(o.get("result")) if as_int(o.get("done")) else "NEPROVEDENO"
                if sid:c.execute("UPDATE revision_inspection_items SET result=?,note=?,sort_order=? WHERE id=?",(result,txt(o.get("note")),as_int(o.get("sort_order")),sid))
                else:sid=c.execute("INSERT INTO revision_inspection_items(revision_id,group_snapshot,label_snapshot,source_ref_snapshot,result,note,sort_order) VALUES(?,?,?,?,?,?,?)",(rid,"Mobilní kontrola",txt(o.get("label")),"PZ-REVIZE Mobile",result,txt(o.get("note")),as_int(o.get("sort_order")))).lastrowid
                h=self.current_check_hash(c,sid);accepted.append({"entity":"checklist","uuid":uuid,"server_id":sid,"server_hash":h})
            # Defects
            defect_id_by_uuid={}
            for o in payload.get("defects") or []:
                uuid=txt(o.get("uuid"));sid=as_int(o.get("server_id"));rid=as_int(o.get("revision_server_id")) or id_by_uuid.get(txt(o.get("revision_uuid")),0)
                if not rid:conflicts.append({"entity":"defect","uuid":uuid,"server_id":sid,"reason":"Chybí synchronizovaná revize."});continue
                cur=self.current_defect_hash(c,sid) if sid else None
                if sid and self.conflict(txt(o.get("server_hash")),cur):conflicts.append({"entity":"defect","uuid":uuid,"server_id":sid,"reason":"Závada byla mezitím změněna na serveru."});continue
                vals=(txt(o.get("text")),txt(o.get("severity")),txt(o.get("severity")),txt(o.get("status")) or "Neodstraněna",txt(o.get("note")))
                if sid:c.execute("UPDATE revision_defects SET defect_text=?,severity=?,defect_class=?,status=?,note=? WHERE id=?",vals+(sid,))
                else:sid=c.execute("INSERT INTO revision_defects(revision_id,defect_text,severity,defect_class,status,note) VALUES(?,?,?,?,?,?)",(rid,)+vals).lastrowid
                defect_id_by_uuid[uuid]=sid;h=self.current_defect_hash(c,sid);accepted.append({"entity":"defect","uuid":uuid,"server_id":sid,"server_hash":h})
            # Photos: upload working copy, optionally duplicate links to defects.
            for o in payload.get("photos") or []:
                uuid=txt(o.get("uuid"));sid=as_int(o.get("server_id"));rid=as_int(o.get("revision_server_id")) or id_by_uuid.get(txt(o.get("revision_uuid")),0)
                if not rid:conflicts.append({"entity":"photo","uuid":uuid,"server_id":sid,"reason":"Chybí synchronizovaná revize."});continue
                stored=None
                if not sid:
                    b64=txt(o.get("data_b64"))
                    if not b64:conflicts.append({"entity":"photo","uuid":uuid,"server_id":0,"reason":"Fotografie nemá obrazová data."});continue
                    raw=base64.b64decode(b64);name=txt(o.get("data_name")) or ("PZ_MOBILE_"+uuid+".jpg");safe="".join(ch for ch in name if ch.isalnum() or ch in "._-")
                    filename=datetime.now().strftime("%Y%m%d_%H%M%S_")+safe;dest=self.attachments/filename;dest.write_bytes(raw);stored="attachments/"+filename
                    sid=c.execute("INSERT INTO revision_photos(revision_id,kind,title,original_name,stored_path,note,sort_order) VALUES(?,?,?,?,?,?,?)",(rid,"working",txt(o.get("title")),safe,stored,txt(o.get("note")),0)).lastrowid
                else:
                    row=c.execute("SELECT stored_path FROM revision_photos WHERE id=?",(sid,)).fetchone();stored=txt(row[0]) if row else ""
                    c.execute("UPDATE revision_photos SET title=?,note=? WHERE id=?",(txt(o.get("title")),txt(o.get("note")),sid))
                # Replace defect copies created by mobile for this working photo path.
                if stored:
                    c.execute("DELETE FROM revision_photos WHERE revision_id=? AND kind='defect' AND stored_path=? AND note LIKE 'MOBILE-LINK:%'",(rid,stored))
                    for z in o.get("defects") or []:
                        did=as_int(z.get("server_id")) or defect_id_by_uuid.get(txt(z.get("uuid")),0)
                        if did:c.execute("INSERT INTO revision_photos(revision_id,defect_id,kind,title,original_name,stored_path,note,sort_order) VALUES(?,?,?,?,?,?,?,?)",(rid,did,"defect",txt(o.get("title")),Path(stored).name,stored,"MOBILE-LINK:"+uuid,0))
                phash=sha({"title":txt(o.get("title")),"note":txt(o.get("note")),"stored":stored});accepted.append({"entity":"photo","uuid":uuid,"server_id":sid,"server_hash":phash})
            # Deletions (currently measurements only).
            for o in payload.get("deletions") or []:
                entity=txt(o.get("entity"));uuid=txt(o.get("uuid"));sid=as_int(o.get("server_id"));expected=txt(o.get("server_hash"))
                if entity=="measurement":
                    # Locate table by trying hashes; delete only when expected hash still matches.
                    found=False
                    for kind,table in (("CIRCUIT","circuits"),("MACHINE","machine_measurements"),("LPS","lps_measurements")):
                        cur=self.current_measurement_hash(c,kind,sid)
                        if cur:
                            found=True
                            if self.conflict(expected,cur):conflicts.append({"entity":entity,"uuid":uuid,"server_id":sid,"reason":"Smazané měření bylo mezitím změněno na serveru."})
                            else:c.execute(f"DELETE FROM {table} WHERE id=?",(sid,));deleted.append({"entity":entity,"uuid":uuid,"server_id":sid})
                            break
                    if not found:deleted.append({"entity":entity,"uuid":uuid,"server_id":sid})
            c.commit()
        self.log("push",f"accepted={len(accepted)} conflicts={len(conflicts)} deleted={len(deleted)}")
        return {"ok":True,"accepted":accepted,"conflicts":conflicts,"deleted":deleted,"server_time":now()}

class Api(BaseHTTPRequestHandler):
    server_version="PZRevizeMobile/"+VERSION
    def _json(self,code,obj):
        raw=json.dumps(obj,ensure_ascii=False).encode("utf-8");self.send_response(code);self.send_header("Content-Type","application/json; charset=utf-8");self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)
    def _auth(self):
        if self.headers.get("X-API-Key","")!=self.server.api_key:self._json(401,{"error":"Neplatný API klíč."});return False
        return True
    def do_GET(self):
        if not self._auth():return
        p=urlparse(self.path).path
        try:
            if p=="/api/mobile/status":self._json(200,{"ok":True,"server":"PZ-REVIZE Mobile Bridge","version":VERSION,"db":self.server.store.db_path.name,"time":now()})
            elif p=="/api/mobile/bootstrap":self._json(200,self.server.store.bootstrap())
            else:self._json(404,{"error":"Neznámá cesta."})
        except Exception as e:self._json(500,{"error":str(e)})
    def do_POST(self):
        if not self._auth():return
        p=urlparse(self.path).path
        try:
            n=int(self.headers.get("Content-Length","0"));
            if n>50*1024*1024:raise ValueError("Požadavek je příliš velký (max. 50 MB).")
            data=json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
            if p=="/api/mobile/push":self._json(200,self.server.store.push(data))
            else:self._json(404,{"error":"Neznámá cesta."})
        except Exception as e:self._json(500,{"error":str(e)})
    def log_message(self,fmt,*args):
        sys.stdout.write("[%s] %s\n"%(self.log_date_time_string(),fmt%args));sys.stdout.flush()

def load_config(base:Path):
    p=base/CONFIG_NAME
    if p.exists():return json.loads(p.read_text(encoding="utf-8"))
    cfg={"api_key":secrets.token_urlsafe(32),"port":8766};p.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding="utf-8");return cfg

def main():
    here=Path(__file__).resolve().parent;cfg=load_config(here)
    default_db=Path(os.environ.get("LOCALAPPDATA",str(Path.home()))) / "PZ-REVIZE" / "pz_revize.db"
    ap=argparse.ArgumentParser(description="PZ-REVIZE Mobile LAN/VPN bridge")
    ap.add_argument("--db",default=str(default_db));ap.add_argument("--attachments",default="");ap.add_argument("--host",default="0.0.0.0");ap.add_argument("--port",type=int,default=int(cfg.get("port",8766)));args=ap.parse_args()
    db=Path(args.db).expanduser().resolve();attachments=Path(args.attachments).expanduser().resolve() if args.attachments else db.parent/"attachments"
    store=Store(db,attachments);srv=ThreadingHTTPServer((args.host,args.port),Api);srv.store=store;srv.api_key=str(cfg["api_key"])
    print("PZ-REVIZE Mobile Bridge",VERSION);print("DB:",db);print("Attachments:",attachments);print("Port:",args.port);print("API KEY:",srv.api_key);print("LAN/VPN URL: http://<IP_TOHOTO_ZARIZENI>:%d"%args.port);print("Ukončení: Ctrl+C");
    try:srv.serve_forever()
    except KeyboardInterrupt:pass
    finally:srv.server_close()

if __name__=="__main__":main()
