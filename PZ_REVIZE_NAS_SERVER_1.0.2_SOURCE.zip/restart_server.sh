#!/bin/sh
set -e
BASE="/volume1/web/PZ_REVIZE_NAS_SERVER"
/bin/sh "$BASE/zastavit_server.sh"
/bin/sh "$BASE/spustit_server.sh"
