#!/bin/sh
set -u
BASE="/volume1/web/PZ_REVIZE_NAS_SERVER"
PIDFILE="$BASE/server.pid"

stop_pid() {
  PID="$1"
  [ -n "$PID" ] || return 0
  if kill -0 "$PID" 2>/dev/null; then
    kill "$PID" 2>/dev/null || true
    i=0
    while kill -0 "$PID" 2>/dev/null && [ "$i" -lt 10 ]; do
      sleep 1
      i=$((i+1))
    done
    if kill -0 "$PID" 2>/dev/null; then
      kill -9 "$PID" 2>/dev/null || true
    fi
  fi
}

if [ -f "$PIDFILE" ]; then
  PID=$(cat "$PIDFILE" 2>/dev/null || true)
  stop_pid "${PID:-}"
  rm -f "$PIDFILE"
fi

# Uklidí případný proces spuštěný ručně z produkční složky bez platného PID souboru.
# Kontroluje skutečný /proc/PID/cwd, takže se nedotkne PZ-SPOTREBICE, PZ-FINANCE ani PZ-SYSTEM.
for PROC in /proc/[0-9]*; do
  [ -d "$PROC" ] || continue
  PID=${PROC#/proc/}
  CWD=$(readlink "$PROC/cwd" 2>/dev/null || true)
  [ "$CWD" = "$BASE" ] || continue
  CMD=$(tr '\000' ' ' < "$PROC/cmdline" 2>/dev/null || true)
  case "$CMD" in
    *"server.py"*|*"pz_nas_server.py"*) stop_pid "$PID" ;;
  esac
done

echo "PZ-REVIZE NAS server zastaven."
